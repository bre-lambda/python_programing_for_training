'''class parnt:
    def fun1(self):
        print('this is a parent class')
class child1(parnt):
    def fun2(self):
        print('this is child fun')
ob=child1()
ob.fun1()
ob.fun2()
'''

'''#only one chile and one parnt class
class parent:
    def fun1(self):
        print('this is function 1')
class child(parent):
    def fun2(self):
        print('this is function 2')
ob=child()
ob.fun1()
ob.fun2()'''

'''
#multiple inheritance involves more than one parent class
class parent:
    def fun1(self):
        print('this is function 1')
class parent2:
    def fun3(self):
        print('fun 3')
class child(parent,parent2):
    def fun2(self):
        print('this is function 2')
ob=child()
ob.fun1()
ob.fun2()
ob.fun3()
'''

'''
#mulitilebel inheritance
#child class acts as a parent class for another child class
class parent:
    def fun1(self):
        print('this is function 1')
class parent2(parent):
    def fun3(self):
        print('fun 3')
class child(parent2):
    def fun2(self):
        print('this is function 2')
ob=child()
ob.fun1()
ob.fun2()
ob.fun3()
'''

'''
#hierarchical inheritance ,,
#more than one type of inheritance
class parent:
    def fun1(self):
        print('this is function 1')
class parent2(parent):
    def fun3(self):
        print('fun 3')
class child(parent2):
    def fun2(self):
        print('this is function 2')
ob=child()
ob1=parent2()
ob.fun1()
ob1.fun1()

'''


'''
#hybired
class parent:
    def fun1(self):
        print('this is function 1')
class parent3:
    def fun4(self):
        print('fun 4')
class parent2(parent,parent3):
    def fun3(self):
        print('fun 3')
class child(parent2):
    def fun2(self):
        print('this is function 2')
ob=child()
ob.fun1()
ob.fun4()


'''

'''
#super function
class parent:
    def fun1(self):
        print('this is fun1')
class child(parent):
    def fun2(self):
        super().fun1()
        print('this is fun 2')
ob=child()
ob.fun2()

'''
#method overriding
class parent:
    def fun1(self):
        print('this is fun1')
class child(parent):
    def fun1(self):#method override
       
        print('this is fun 2')
ob=child()
ob.fun1()
