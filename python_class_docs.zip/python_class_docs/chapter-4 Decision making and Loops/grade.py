grad=float(input('enter your mark'))
if grad>=80:
    print('u got A grade')
elif grad>=60:
    print('U got B grade')
elif grad>=40:
    print('U got C grade')
else:
    print('N/G')
