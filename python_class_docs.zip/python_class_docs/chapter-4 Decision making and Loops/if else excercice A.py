#Q1
deg=int(input('enter degree'))
mes=str(input('enter mes'))
c='c'
f='f'
if mes==c:
   cx=lambda Ce:(9/5)*(deg)+32
   print(cx(deg),':degrees fahrenheit')
elif mes==f:
   fx=lambda fe:(5/9)*(deg-32) 
   print(fx(deg),':degrees celsius')
else:
  print('wrong input')
def sum(x, y):
    sum = x + y
    if sum in range(15, 20):
        return 20
    else:
        return sum
n1=float(input('enter the length'))
n2=float(input('enter the width'))
print(sum(n1,n2))
def sum(x, y):
    sum = x + y
    if sum in range(15, 20):
        return 20
    else:
        return sum
#2
'''n1=float(input('enter the length'))
n2=float(input('enter the width'))
summ=n1+n2
if summ>=15 and summ<=20:
    summ=20
    print('sum is :',summ)
print('sum is :',summ)'''
def sum(x, y):
    sum = x + y
    if sum in range(15, 20):
        return 20
    else:
        return sum
n1=float(input('enter the length'))
n2=float(input('enter the width'))
print(sum(n1,n2))
def sum(x, y):
    sum = x + y
    if sum in range(15, 20):
        return 20
    else:
        return sum

print(sum(10, 6))
print(sum(10, 2))
print(sum(10, 12))
#3
text = input("Input a string: ")
text = text.strip()
if len(text) < 1:
    print("Input a valid text")
else:
    if all(text[i] in "0123456789" for i in range(len(text))):
        print("The string is an integer.")
    elif (text[0] in "+-") and \
         all(text[i] in "0123456789" for i in range(1,len(text))):
         print("The string is an integer.")
    else:
        print("The string is not an integer.")
#4
l=float(input('enter the length'))
w=float(input('enter the width'))
h=float(input('enter the hight'))

if l==w and w==h and l==h:
    print('the trianigle is equlatrial')
elif l==w or w==h or l==h:
    print('triangle is isociles')
else:
    print('triangle is escalen')
