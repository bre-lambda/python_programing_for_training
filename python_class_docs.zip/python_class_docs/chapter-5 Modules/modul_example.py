def add(a, b):
   """This program adds two
   numbers and return the result"""
   result = a + b
   return result
'''Here, we have defined a function add() inside a module named modul_example.
The function takes in two numbers and returns their sum.
We can import the definitions inside a module to another module or the interactive
interpreter in Python.We use the import keyword to do this.
To import our previously defined module example,
we type the following in the Python prompt.
           >>>import modul_example
This does not import the names of the functions defined in example directly in
the current symbol table. It only imports the module name example there.
Using the module name we can access the function using the dot . operator. For example:

           >>> example.add(4,5.5)
             9.5
'''

