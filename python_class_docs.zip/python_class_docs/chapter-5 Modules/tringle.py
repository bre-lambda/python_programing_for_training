#python cod drowing a tringle
import turtle 
# Screen() method to get screen 
#wn=turtle.Screen()    
# creating tess object 
Heyday=turtle.Turtle()   
def triangle(x,y):   
    # it is used to draw out the pen 
    Heyday.penup()   
    # it is used to move curson at x  
    # and y position 
    Heyday.goto(x,y)    
    # it is used to draw in the pen 
    Heyday.pendown() 
    for i in range(3):     
          # move cursor 100 unit  
        # digit forward 
        Heyday.forward(100)     
        # turn cursor 120 degree left 
        Heyday.left(120)   
        # Again,move cursor 100 unit  
        # digit forward 
        Heyday.forward(100)      
# special built in function to send current  
# position of cursor to traingle 
turtle.onscreenclick(triangle,1)  
turtle.listen()  
# hold the screen  
turtle.done()




