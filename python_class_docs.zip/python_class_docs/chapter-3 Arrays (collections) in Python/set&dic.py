set1={'ayanitu','guyatu','chalitu',1,3,43}
print(set1)
#unordered and unindexed
print(set1[1]) #error b/s set is unindexed
