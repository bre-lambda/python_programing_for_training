#quasion no 1
print('quasion no 1')
r=lambda a:a+15
print(r(10))
r=lambda x, y:x*y
print(r(12,4))
#quasion no 2
print('quasion no 2')
def fc(n):
    return lambda x:x*n
r=fc(2)
print('double=',r(15))
r=fc(3)
print('triple =',r(15))
r=fc(4)
print('quadrupl =',(15))
r=fc(5)
print('quintuple',r(15))
#quasion no 3
print('quasion no 3')
nums=[1,2,3,4,5,6,7,8,9,10]
print('orginal list of integers:')
print(nums)
print('even numbers :')
even_nums=list(filter(lambda x:x%2==0,nums))
print(even_nums)
print('\nodd nums :')
odd_nums=list(filter(lambda x:x%2 !=0,nums))
print(odd_nums)
#quasion no 4
print('quasion no 4')
nums=[1,2,3,4,5,6,7,8,9,10]
print('orginal list')
print(nums)
print('\nsquare')
square_nums=list(map(lambda x:x**2, nums))
print(square_nums)
print('\ncub')
cub_nums=list(map(lambda x:x**3,nums))
print(cub_nums)

#quasion no 5
print('quasion no 5')
weekdays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
days = filter(lambda day: day if len(day)==6 else '', weekdays)
for d in days:
  print(d)
#quasion no 6
print('quasion no 6')
nums1 = [1, 2, 3]
nums2 = [4, 5, 6]
print("Original list:")
print(nums1)
print(nums2)
result = map(lambda x, y: x + y, nums1, nums2)
print("\nResult: after adding two list")
print(list(result))
#quasion no 7
print('quasion no 7')
nums = [19, 65, 57, 39, 152, 639, 121, 44, 90, 190]
print("Orginal list:")
print(nums) 
result = list(filter(lambda x: (x % 19 == 0 or x % 13 == 0), nums)) 
print("\nNumbers of the above list divisible by nineteen or thirteen:")
print(result)
